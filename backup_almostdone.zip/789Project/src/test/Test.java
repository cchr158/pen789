package test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import org.zaproxy.zap.ZAP;

import framesAndPanels.Constants;

public class Test {

	public static void main(String[] args) throws IOException {
//		new Test().getFiles(Paths.get(System.getProperty("user.dir"),"ZAP_Instal_Files").toString());
		try {
			ZAP.main(new String[]{});
//			ZAP.main(new String[]{"-daemon", "-config", "scanner.strength=HIGH", "-host",Constants.DEFUALT_LOCAL_PROXY_ADDRESS, "-port",
//					Integer.toString(Constants.DEFUALT_PORT), "-config", "api.key="+"somekey","-dir", Constants.runDir, "-installdir",Constants.installDir});
		} catch (Exception e) {
			e.printStackTrace();
		}
//		System.out.println(Constants.installDir);
//		System.out.println(Constants.runDir);
		
	}

	private void getFiles(String path) {
		File directory = new File(path);

	    // get all the files from a directory
	    File[] fList = directory.listFiles();
	    for (File file : fList) {
	        if (file.isFile()) {
	        	System.out.println("\""+file.getAbsolutePath().replace(System.getProperty("user.dir")+"\\"+"ZAP_Instal_Files", "")+"\",");
	        } else if (file.isDirectory()) {
	        	getFiles(file.getAbsolutePath());
	        }
	    }
	    if(fList.length==0){
	    	System.out.println("\""+directory.getAbsolutePath().replace(System.getProperty("user.dir")+"\\"+"ZAP_Instal_Files", "")+"\\\",");
	    }
	}
}
