package framesAndPanels;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import pen789.pen789;

class ZapProxySettings {
	private pen789 myPen789;
	private JFrame ProxyFrame;
	private JPanel titlePanel;
	private JPanel inputPanel;
	private JPanel buttonPanel;
	private JTextPane title;
	private JLabel address;
	private JTextField addressField;
	private JLabel port;
	private JTextField portField;
	private JLabel APIKey;
	private JTextField APIKeyField;
	private JComboBox<String> attackStrength;
	private JButton okButton;
	private JButton helpButton;

	ZapProxySettings(pen789 p) {
		this.myPen789 = p;
		this.ProxyFrame = new JFrame("OWSAP ZAP Proxy settings");
		this.ProxyFrame.addWindowListener(this.myPen789.exitListener);
		this.ProxyFrame.setPreferredSize(new Dimension(2*Constants.SCREEN_SIZE.width/5,Constants.SCREEN_SIZE.height/3));
		this.titlePanel = new JPanel();
		this.inputPanel = new JPanel();
		this.buttonPanel = new JPanel();
		this.title = new JTextPane();
		this.address = new JLabel("ZAP Proxy Address: ");
		this.port = new JLabel("Proxy Port: ");
		this.APIKey = new JLabel("ZAP API Key: ");
		this.addressField = new JTextField();
		this.portField = new JTextField();
		this.APIKeyField = new JTextField();
		this.attackStrength = new JComboBox<String>(new String[]{"Low","Medium","High", "Insane"});
		this.okButton = new JButton("OK");
		this.helpButton = new JButton("Help");
		displayTitlePanel();
		proxyInputs();
		this.myPen789.nextFrame(ProxyFrame);
	}

	private void proxyInputs() {
		this.inputPanel.setLayout(new GridBagLayout());
		this.address.setFont(new Font(this.address.getFont().getFontName(), Font.PLAIN, Constants.LABLE_FONT_SIZE));
		this.port.setFont(new Font(this.port.getFont().getFontName(), Font.PLAIN, Constants.LABLE_FONT_SIZE));
		this.APIKey.setFont(new Font(this.APIKey.getFont().getFontName(), Font.PLAIN, Constants.LABLE_FONT_SIZE));
		this.addressField.setFont(new Font(this.addressField.getFont().getFontName(), Font.PLAIN, Constants.TEXTFEILD_FONT_SIZE));
		this.addressField.setText(this.myPen789.ZAP_ADDRESS);
		this.portField.setFont(new Font(this.portField.getFont().getFontName(), Font.PLAIN, Constants.TEXTFEILD_FONT_SIZE));
		this.portField.setText(Integer.toString(this.myPen789.ZAP_PORT));
		this.APIKeyField.setFont(new Font(this.APIKeyField.getFont().getFontName(), Font.PLAIN, Constants.TEXTFEILD_FONT_SIZE));
		this.addressField.setPreferredSize(Constants.TEXT_DIMENSION);
		this.portField.setPreferredSize(Constants.TEXT_DIMENSION);
		this.APIKeyField.setPreferredSize(Constants.TEXT_DIMENSION);
		this.APIKeyField.setText(this.myPen789.ZAP_API_KEY);
		this.attackStrength.setSelectedIndex(2);
		this.attackStrength.setFont(new Font(this.attackStrength.getFont().getFontName(), Font.PLAIN, Constants.TEXTFEILD_FONT_SIZE));
		this.attackStrength.setPreferredSize(Constants.TEXT_DIMENSION);

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(0, 15, 0, 0);
		c.gridheight = 1;
		c.gridwidth = 3;
		c.gridx = 0;
		c.gridy = 0;
		this.inputPanel.add(this.address, c);
		c.gridy = 1;
		c.insets = new Insets(15, 15, 0, 0);
		this.inputPanel.add(this.port, c);
		c.gridy = 2;
		this.inputPanel.add(this.APIKey, c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.insets = new Insets(15, 0, 0, 15);
		c.gridx = 3;
		c.gridy = 0;
		this.inputPanel.add(this.addressField, c);
		c.gridy = 1;
		this.inputPanel.add(this.portField, c);
		c.gridy = 2;
		this.inputPanel.add(this.APIKeyField, c);
		c.gridy = 3;
		this.inputPanel.add(this.attackStrength, c);

		this.okButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				okFunction();
			}
		});
		this.helpButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				helpFunction();
			}
		});

		c.fill = GridBagConstraints.NONE;
		c.gridwidth = 1;
		c.gridx = 4;
		c.gridy = 4;
		c.insets = new Insets(10, 0, 10, 0);
		c.anchor = GridBagConstraints.EAST;
		this.buttonPanel.add(this.okButton);
		this.buttonPanel.add(this.helpButton);
		this.inputPanel.add(this.buttonPanel, c);

		ProxyFrame.add(this.inputPanel, BorderLayout.CENTER);
	}

	private void helpFunction() {
		JFrame helpFrame = new JFrame("Proxy settings help");
		helpFrame.addWindowListener(this.myPen789.exitListener);
		JPanel helpPanel = new JPanel(new GridBagLayout());
		JTextPane helpText = new JTextPane();
		GridBagConstraints helpC = new GridBagConstraints();
		JButton helpOK = new JButton("OK");
		helpText.setContentType("text/html");
//		TODO Check help text.
		helpText.setText("<HTML><head><style type=\"text/css\">li {font-size: 24;}</style>"
				+ "</head><body><p align=\"center\"><FONT size='7'><b>Proxy Settings Help</b></FONT></p>"
				+ "<P><FONT size='4'>This help section will help you complete the ZAP proxy settings for pen789."
				+ "You should not modifie the proxy settings unless you are fermilar with the ZAP API.</FONT></P>"
				+ "<ol><li><FONT size='6'>Proxy Address:</FONT><p><FONT size='4'>The Local ZAP proxy address can be found by"
				+ " going to the ZAP API and selecting Tools -> Options -> Local Proxy. Copy the Address value displayed here.</FONT></p>"
				+ "</li><li><FONT size='6'>Proxy Port:</FONT><p><FONT size='4'>The Local ZAP proxy port can be found by going to the ZAP"
				+ " API and selecting Tools -> Options -> Local Proxy. Copy the Port value displayed here.</FONT></p></li>"
				+ "<li><FONT size='6'>ZAP API Key:</FONT><p><FONT size='4'>The ZAP API Key is used to prevent other applications from"
				+ " accessing the ZAP API without permission. The ZAP API Key can be found by going to the ZAP API and slection "
				+ "Tools -> Options -> API</FONT></p></li></ol><P><FONT size='4'>More information is avalable at "
				+ "<a href=\"https://www.owasp.org/index.php/OWASP_Zed_Attack_Proxy_Project\">OWASP_Zed_Attack_Proxy_Project</a></FONT></P>"
				+ "</body></HTML>");
		helpText.setEditable(false);
		helpText.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent e) {
				if (Desktop.isDesktopSupported()) {
					if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
						try {
							Desktop.getDesktop().browse(
									new URI("https://www.owasp.org/index.php/OWASP_Zed_Attack_Proxy_Project"));
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				} else {
					System.err.println("Desktop not supported.");
				}
			}
		});
		helpOK.addActionListener(this.myPen789.cancleButtonListerner);

		helpC.gridheight = 1;
		helpC.gridy = 0;
		helpC.insets = new Insets(0,15,0,15);
		helpPanel.add(helpText, helpC);
		helpC.insets = new Insets(15,0,15,0);
		helpC.gridy = 1;
		helpPanel.add(helpOK, helpC);
		helpFrame.add(helpPanel, BorderLayout.CENTER);
		myPen789.nextFrame(helpFrame);
	}

	private void okFunction() {
		if(this.addressField.getText().isEmpty()){
			JOptionPane.showMessageDialog(null, "ZAP Proxy address is required to connect to the local proxy.");
		}else if(this.portField.getText().isEmpty()){
			JOptionPane.showMessageDialog(null, "ZAP Proxy port number is required to connect to the local proxy.");
		}else if (this.APIKeyField.getText().isEmpty() || this.APIKeyField.getText().length() < 26){
			JOptionPane.showMessageDialog(null, "ZAP API key must be at least 26 characters long and is required to run any tests.");
		}else{
			myPen789.setZAPAddress(this.addressField.getText());
			int portNumber = -1;
			try{
				portNumber = Integer.parseInt(this.portField.getText());
			}catch(NumberFormatException e){
				JOptionPane.showMessageDialog(null, "ZAP Proxy port number must be a valid integer.");
			}
			if(portNumber >= 0 && portNumber <= 65535){
				myPen789.setZAPPort(portNumber);
			}else{
				JOptionPane.showMessageDialog(null, "ZAP Proxy port number must be between 0 and 65535.");
			}
			myPen789.setZAPAPIKEY(this.APIKeyField.getText());
			myPen789.setAttackStrength(this.attackStrength.getItemAt(this.attackStrength.getSelectedIndex()));
			myPen789.prevFrame();
		}
	}

	private void displayTitlePanel() {
		this.title.setFont(new Font(this.title.getFont().getFontName(), Font.BOLD, Constants.TITLE_FONT_SIZE));
		this.title.setText("ZAP Proxy Settings");
		this.title.setEditable(false);
		this.titlePanel.add(this.title);
		this.ProxyFrame.add(this.titlePanel, BorderLayout.NORTH);
	}
}
