package framesAndPanels;

import pen789.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import org.zaproxy.clientapi.core.ClientApiException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;

public class HomeScreen {
	private pen789 myPen789;
	private JPanel instructionsPanel;
	private JTextPane zapURL;
	private JPanel inputsPanel;
	private JLabel targetLabel;
	private JButton zapProxyButton;
	private JTextField targetTextField;
	private JButton okButton;
	private JButton canclButton;
	private JFrame homeFrame;

	public HomeScreen(String name, pen789 myPen789) {
		this.myPen789 = myPen789;
		homeFrame = new JFrame(name);
		homeFrame.addWindowListener(this.myPen789.exitListener);
		homeFrame.setPreferredSize(new Dimension(4*Constants.SCREEN_SIZE.width/5,Constants.SCREEN_SIZE.height/2));
		this.instructionsPanel = new JPanel();
		this.zapURL = new JTextPane();
		instructionOfUse();

		this.inputsPanel = new JPanel();
		this.zapProxyButton = new JButton();
		this.targetLabel = new JLabel();
		this.targetTextField = new JTextField();
		this.okButton = new JButton("OK");
		this.canclButton = new JButton("Cancle");
		inputFeilds();

		homeFrame.add(this.instructionsPanel, BorderLayout.NORTH);
		homeFrame.add(this.inputsPanel, BorderLayout.CENTER);
		this.myPen789.nextFrame(homeFrame);
	}

	private void inputFeilds() {
		GridBagConstraints c = new GridBagConstraints();
		this.inputsPanel.setLayout(new GridBagLayout());
		this.zapProxyButton.setText("ZAP Proxy Settings");
		this.zapProxyButton.setFont(new Font(this.zapProxyButton.getFont().getFontName(), Font.PLAIN, Constants.BUTTON_FONT_SIZE));
		this.zapProxyButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				new ZapProxySettings(myPen789);
			}
		});
		this.targetLabel.setFont(new Font(this.targetLabel.getFont().getFontName(), Font.PLAIN, Constants.LABLE_FONT_SIZE));
		this.targetLabel.setText("Enter target IP/URL: ");
		this.targetTextField.setFont(new Font(this.targetTextField.getFont().getFontName(), Font.PLAIN, Constants.LABLE_FONT_SIZE));
		this.targetTextField.setPreferredSize(Constants.TEXT_DIMENSION);
		this.targetTextField.setText(this.myPen789.target);
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 0.0;
		c.gridheight = 1;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridx = 0;
		c.gridy = 0;
		this.inputsPanel.add(this.zapProxyButton, c);
		c.gridwidth = 3;
		c.gridy = 1;
		c.insets = new Insets(10, 0, 0, 0);
		this.inputsPanel.add(this.targetLabel, c);
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridy = 1;
		c.gridx = 3;
		this.inputsPanel.add(this.targetTextField, c);

		this.canclButton.addActionListener(this.myPen789.cancleButtonListerner);

		this.okButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				okButtonPushed();
			}
		});
		
		JPanel controlButtons = new JPanel();
		controlButtons.setLayout(new GridLayout(1, 0));
		controlButtons.add(this.okButton);
		controlButtons.add(this.canclButton);
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.EAST;
		c.gridy = 2;
		c.gridx = 5;
		c.gridwidth = 1;
		c.insets = new Insets(10, 0, 10, 0);
		this.inputsPanel.add(controlButtons, c);
	}

	private void okButtonPushed() {
		if(this.targetTextField.getText().isEmpty()){
			JOptionPane.showMessageDialog(null, "A target is needed to run the tests against.");
		}else{
			this.myPen789.setTarget(this.targetTextField.getText());
			try {
				pen789.api.context.includeInContext(this.myPen789.ZAP_API_KEY, pen789.contextName, this.myPen789.target);
				if(this.myPen789.ZAP_ADDRESS_SET && this.myPen789.ZAP_API_KEY_SET && this.myPen789.ZAP_PORT_SET){
					new AttackOptionScreen(this.myPen789);
				}else{
					JOptionPane.showMessageDialog(null, "ZAP proxy settings must be configured in order to perform any tests.");
				}
			} catch (ClientApiException e) {
				JOptionPane.showMessageDialog(null, "ZAP failed to add this target to this context.");
			}
		}
	}

	private void instructionOfUse() {
		String instructions = "<HTML><head></head><body><FONT size=\"7\"><p align=\"center\"><b>Welcome to pen789!</b>"
				+ "</p></FONT><FONT size=\"6\"><p>This is a basic penetration testing tool. This tool requires that "
				+ "<a href='https://www.owasp.org/index.php/OWASP_Zed_Attack_Proxy_Project' "
				+ "target=\"_blank\">OWASP ZAP Proxy</a> be installed and running before this tool can be used.</p>"
				+ "<p>Once ZAP is installed set up the ZAP proxy in the ZAP Proxy Settings menu.Do NOT change any of "
				+ "the defualts unless you are fermiliar with the ZAP API.</p>"
				+ "<p>You must then set a target before running "
				+ "any tests.</p></FONT></body></HTML>";
		this.zapURL.setContentType("text/html");
		this.zapURL.setText(instructions);
		this.zapURL.setEditable(false);
		this.zapURL.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent e) {
				if (Desktop.isDesktopSupported()) {
					if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
						try {
							Desktop.getDesktop()
									.browse(new URI("https://www.owasp.org/index.php/OWASP_Zed_Attack_Proxy_Project"));
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				} else {
					System.err.println("Desktop not supported.");
				}
			}
		});
		this.instructionsPanel.add(this.zapURL);
	}
}
