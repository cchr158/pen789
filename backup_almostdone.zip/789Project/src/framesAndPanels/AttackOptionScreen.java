package framesAndPanels;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import pen789.pen789;

public class AttackOptionScreen {

	private pen789 myPen789;

	AttackOptionScreen(pen789 myPen789) {
		this.myPen789 = myPen789;
		this.myPen789.resetFrames();
		JFrame attackFrame = new JFrame("pen789");
		attackFrame.addWindowListener(this.myPen789.exitListener);
		attackFrame.setPreferredSize(new Dimension(2*Constants.SCREEN_SIZE.width/5,2*Constants.SCREEN_SIZE.height/5));
		title(attackFrame);
		buttons(attackFrame);
		this.myPen789.nextFrame(attackFrame);
	}

	private void buttons(JFrame attackFrame) {
		JPanel buttonPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		c.anchor = GridBagConstraints.CENTER;
		c.gridheight = 1;
		c.gridwidth = 6;
		c.insets = new Insets(5,0,5,0);
		c.gridx = 0;
		c.gridy = 0;
		
		JCheckBox xssCheckBox = new JCheckBox("XSS");
		xssCheckBox.setFont(new Font(xssCheckBox.getFont().getFontName(), Font.PLAIN, Constants.BUTTON_FONT_SIZE));
		JCheckBox CSRFCheckBox = new JCheckBox("(Login) CSRF");
		CSRFCheckBox.setFont(new Font(CSRFCheckBox.getFont().getFontName(), Font.PLAIN, Constants.BUTTON_FONT_SIZE));
		JCheckBox SQLCheckBox = new JCheckBox("SQL injection");
		SQLCheckBox.setFont(new Font(SQLCheckBox.getFont().getFontName(), Font.PLAIN, Constants.BUTTON_FONT_SIZE));
		
		JButton HelpButton = new JButton("Help");
		HelpButton.setFont(new Font(HelpButton.getFont().getFontName(), Font.PLAIN, Constants.BUTTON_FONT_SIZE));
		HelpButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				attackHelp();
			}
		});
		JButton nextButton = new JButton("next");
		nextButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				myPen789.attack(xssCheckBox.isSelected(), CSRFCheckBox.isSelected(), SQLCheckBox.isSelected());
			}
		});
		JButton backButton = new JButton("Back");
		backButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				attackFrame.dispose();
				new pen789(myPen789.ZAP_ADDRESS, myPen789.ZAP_PORT, myPen789.ZAP_API_KEY, myPen789.target);
			}
		});
		buttonPanel.add(xssCheckBox, c);
		c.gridy = GridBagConstraints.RELATIVE;
		buttonPanel.add(CSRFCheckBox, c);
		c.gridy = GridBagConstraints.RELATIVE;
		buttonPanel.add(SQLCheckBox, c);
		c.gridy = GridBagConstraints.RELATIVE;
		buttonPanel.add(HelpButton, c);
		c.fill = GridBagConstraints.NONE;
		c.anchor = GridBagConstraints.EAST;
		c.gridwidth = 1;
		c.insets = new Insets(5,0,5,0);
		c.gridy = GridBagConstraints.RELATIVE;
		c.gridx = 4;
		buttonPanel.add(nextButton, c);
		c.gridx = 5;
		buttonPanel.add(backButton, c);
		attackFrame.add(buttonPanel);
	}

	protected void attackHelp() {
		JFrame helpFrame = new JFrame("Attack Help");
		helpFrame.addWindowListener(this.myPen789.exitListener);
		JPanel helpPanel = new JPanel(new GridBagLayout());
		JTextPane helpText = new JTextPane();
		JButton okButton = new JButton("OK");
		okButton.addActionListener(this.myPen789.cancleButtonListerner);
		GridBagConstraints c = new GridBagConstraints();
		c.insets = new Insets(5, 10, 5, 10);
		c.gridx = 0;
		c.gridy = 0;
		helpText.setContentType("text/html");
//		TODO add help text.
		helpText.setText("");
		helpText.setEditable(false);
		helpText.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent e) {
				if (Desktop.isDesktopSupported()) {
					if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
						try {
							Desktop.getDesktop()
									.browse(new URI("https://www.owasp.org/index.php/OWASP_Zed_Attack_Proxy_Project"));
						} catch (Exception e1) {
							e1.printStackTrace();
						}
					}
				} else {
					System.err.println("Desktop not supported.");
				}
			}
		});
		helpPanel.add(helpText, c);
		c.gridy = 1;
		helpPanel.add(okButton, c);
		helpFrame.add(helpPanel, BorderLayout.NORTH);
		this.myPen789.nextFrame(helpFrame);
	}

	private void title(JFrame attackFrame) {
		JTextPane titleText = new JTextPane();
		titleText.setContentType("text/html");
		titleText.setText("<HTML><head><style>p{font-weight: bold;font-size: 72;}</style></head>"
				+ "<BODY><p>Select An Attack</p></BODY></HTML>");
		titleText.setEditable(false);
		JPanel titlePanel = new JPanel();
		titlePanel.add(titleText);
		attackFrame.add(titlePanel, BorderLayout.NORTH);
	}

}
